﻿using System;
using Learn_C_Sharp;

namespace Learn_C_Sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // These lines of code is basically how the conversation exists
            
            Console.Title = "Learn";
            Console.WriteLine("Ello there, my name is Sarah, and u?"); // Me asking 4 ur name
            Console.ReadLine(); // How u write ur message.
            Console.WriteLine("Cool! How's life?"); // Me asking if u're ok
            Console.ReadLine();
            Console.WriteLine("I would love to introduce u more about me."); // Me wants to intro more 'bout myself
            Console.WriteLine("I'm a *BEGINNER* game dev who makes plain MS DOS games. I use C# to code.\n How about u?"); // Me intro ME
            Console.ReadLine();
            Console.WriteLine("What? Another error? Really?\nI have some bugs to fix now,see u!"); // Me frustrating with the errors so ends da conv
            Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Red; // How I change the "SYSTEM" message to red
            Console.WriteLine("SYSTEM: Press any key to close."); // "SyStEm" message lmao
            Console.ReadKey(); // how the system detects if a key is press
        }
    }
}